package com.example.cyclelogo;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.os.Bundle;
import android.os.Environment;
import android.text.util.Linkify;
import android.view.View;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    retrieveData getData = new retrieveData();
    String dataDate = getData.getDate();
    CheckBox cramp, nausea, backache, none, breastpain;
    predictDate prediction = new predictDate();
    String predictedMenstruationEnd = prediction.getMenstruationEnd(dataDate);
    String predictedFollicularPhaseStart = prediction.getFollicularPhaseStart(predictedMenstruationEnd);
    String predictedFollicularPhaseEnd = prediction.getFollicularPhaseEnd(predictedFollicularPhaseStart);
    String predictedOvulationStart = prediction.getOvulationStart(predictedFollicularPhaseEnd);
    String predictedOvulationEnd = prediction.getOvulationEnd(predictedOvulationStart);
    String predictedLutealPhaseStart = prediction.getLutealPhaseStart(predictedOvulationEnd);
    String predictedLutealPhaseEnd = prediction.getLutealPhaseEnd(predictedLutealPhaseStart);
    String predictedMenstruationNext = prediction.getNextMenstruation(predictedLutealPhaseEnd);
    private int EXTERNAL_STORAGE_PERMISSION_CODE = 23;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //displayText = findViewById(R.id.displayData);
        // Requesting Permission to access External Storage
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                EXTERNAL_STORAGE_PERMISSION_CODE);
    }
    public void question (View view){
        setContentView(R.layout.activity_second);
    }

    public void backtoMain(View view) {
        //click back to main from activity2
        setContentView(R.layout.activity_main);
    }
    public void backtoSecond(View view) {
        //click back to main from activity2
        setContentView(R.layout.activity_second);
    }

    public void next(View view){
        //goes to activity secondA
        setContentView(R.layout.activity_second2);
        TextView credit = (TextView) findViewById(R.id.credit);
        credit.setText("Credit: https://www.ivf.com.au/blog/understanding-your-cycle-and-timing-for-conception#:~:text=Day%201%20of%20your%20cycle,to%20develop%20within%20your%20ovaries.");
        Linkify.addLinks(credit , Linkify.WEB_URLS);
    }

    public void addInput(View view) {
        //Add input
        setContentView(R.layout.activity_third);
    }

    public void chooseLight(View view) {
        //Appear message when choose light
        Toast toast = new Toast(getApplicationContext());
        toast.setText("You chose light");
        toast.show();
        setContentView(R.layout.activity_fourth);
        getData.setBleeding("Light");
    }

    public void chooseMedium(View view) {
        //Appear message when choose light
        Toast toast = new Toast(getApplicationContext());
        toast.setText("You chose medium");
        toast.show();
        setContentView(R.layout.activity_fourth);
        getData.setBleeding("Medium");
    }

    public void chooseHeavy(View view) {
        //Appear message when choose light
        Toast toast = new Toast(getApplicationContext());
        toast.setText("You choose heavy");
        toast.show();
        setContentView(R.layout.activity_fourth);
        getData.setBleeding("Heavy");
    }

    public void chooseExtreme(View view) {
        //Appear message when choose light
        Toast toast = new Toast(getApplicationContext());
        toast.setText("You choose extreme");
        toast.show();
        setContentView(R.layout.activity_fourth);
        getData.setBleeding("Extreme");
    }

    public void chooseHappy(View view) {
        //Appear message when choose happy
        Toast toast = new Toast(getApplicationContext());
        toast.setText("Keep the positivity going!");
        toast.show();
        setContentView(R.layout.activity_fifth);
        getData.setFeeling("Happy");
    }

    public void chooseMeh(View view) {
        //Appear message when choose meh
        Toast toast = new Toast(getApplicationContext());
        toast.setText("It's okay to not feel anything -_-");
        toast.show();
        setContentView(R.layout.activity_fifth);
        getData.setFeeling("Meh");
    }

    public void chooseSad(View view) {
        //Appear message when choose sad
        Toast toast = new Toast(getApplicationContext());
        toast.setText("Aww, sorry that you feel that way :(!");
        toast.show();
        setContentView(R.layout.activity_fifth);
        getData.setFeeling("Sad");
    }

    public void chooseStress(View view) {
        //Appear message when choose stressed
        Toast toast = new Toast(getApplicationContext());
        toast.setText("Purrhaps, you should get rest");
        toast.show();
        setContentView(R.layout.activity_fifth);
        getData.setFeeling("Stress");
    }
    public void Check(View V){
        cramp = (CheckBox)findViewById(R.id.crampBox);
        nausea = (CheckBox)findViewById(R.id.nauseaBox);
        backache = (CheckBox)findViewById(R.id.backacheBox);
        breastpain = (CheckBox)findViewById(R.id.breastBox);
        none = (CheckBox)findViewById(R.id.noneBox);
        String msg = " ";
        if(cramp.isChecked())
            //check if cramp is selected
            msg = msg + " Cramp ";
        if (nausea.isChecked())
            //check if nausea is selected
            msg = msg + " Nausea ";
        if (backache.isChecked())
            //check if backache is selected
            msg = msg + " Backache ";
        if (breastpain.isChecked())
            //breast pain is selected
            msg = msg + " Breast Pain ";
        if (none.isChecked())
            //breast pain is selected
            msg = msg + " N/A ";
        getData.setSymptomChoice(msg);
    }
    public void clickNext(View view) {
        //Appear message when choose next
        Toast toast = new Toast(getApplicationContext());
        toast.setText("It is ok to feel these symptoms some time, but please visit a gynecologist if these bother you");
        toast.show();
        setContentView(R.layout.activity_sixth);
    }

    public void chooseOily(View view) {
        //Appear message when choose oily hair
        Toast toast = new Toast(getApplicationContext());
        toast.setText("It's okay, blame it on the hormones!");
        toast.show();
        setContentView(R.layout.activity_seventh);
        getData.setHairChoice("Oily");
    }

    public void chooseDry(View view) {
        //Appear message when choose dry hair
        Toast toast = new Toast(getApplicationContext());
        toast.setText("It's okay, blame it on the hormones!");
        toast.show();
        setContentView(R.layout.activity_seventh);
        getData.setHairChoice("Dry");
    }

    public void chooseFabulous(View view) {
        //Appear message when choose fabulous hair
        Toast toast = new Toast(getApplicationContext());
        toast.setText("Ooh!");
        toast.show();
        setContentView(R.layout.activity_seventh);
        getData.setHairChoice("Fabulous");
    }

    public void chooseBald(View view) {
        //Appear message when choose bald for hair
        Toast toast = new Toast(getApplicationContext());
        toast.setText("Bald is bold ;)");
        toast.show();
        setContentView(R.layout.activity_seventh);
        getData.setHairChoice("Bald");
    }

    public void chooseGlow(View view) {
        //Appear message when choose glow for skin
        Toast toast = new Toast(getApplicationContext());
        toast.setText("Ooh, that's flawless!");
        toast.show();
        getData.setSkinChoice("Flawless");
        setContentView(R.layout.activity_eighth);
    }

    public void chooseAcne(View view) {
        //Appear message when choose acne for skin
        Toast toast = new Toast(getApplicationContext());
        toast.setText("Blame it on the hormones!");
        toast.show();
        getData.setSkinChoice("Acne");
        setContentView(R.layout.activity_eighth);
    }


    private void writeTextData(File file, String data) {
        FileOutputStream fileOutputStream = null;
        try {
            fileOutputStream = new FileOutputStream(file);
            fileOutputStream.write(data.getBytes());
            Toast.makeText(this, "Done" + file.getAbsolutePath(), Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (fileOutputStream != null) {
                try {
                    fileOutputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    public void savePublicly(View view) {
        String dataBleeding = getData.getBleeding();
        String dataFeeling = getData.getFeeling();
        String dataHairChoice = getData.getHairChoice();
        String dataSkinChoice = getData.getSkinChoice();
        String dataSymptoms = getData.getSymptomChoice();
        String dataConcat = "Your period started: " + dataDate + "\nEstimated the end of your period: " + predictedMenstruationEnd +
                "\nEstimated Follicular Phase Starts: " + predictedFollicularPhaseStart + "\nEstimated Follicular Ends: " + predictedFollicularPhaseEnd +
                "\nEstimated Ovulation Starts: " + predictedOvulationStart + "\nEstimated Ovulation End: " + predictedOvulationEnd +
                "\nEstimated Luteal Phase Start: " + predictedLutealPhaseStart + "\nEstimated Luteal Phase End: " + predictedLutealPhaseEnd +
                "\nEstimated the next menstruation: " + predictedMenstruationNext +
                "\nBleeding: " + dataBleeding + "\nFeeling: " + dataFeeling + "\nHair Condition: " + dataHairChoice + "\nSkin Condition: " + dataSkinChoice + "\nSymptoms: " + dataSymptoms;
        //Save file in Downloads folder
        File folder = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        /*String fileType = ".txt";
        String concatFileName = dataDate+fileType;*/
        File file = new File(folder, "test.txt");
        //test dataDate
        writeTextData(file, dataConcat);
        Toast toast = new Toast(getApplicationContext());
        setContentView(R.layout.activity_main);
        toast.setText("Data saved!");
        toast.show();
    }
    public void readFile(View view) {
        // Accessing the saved data from the downloads folder
        File folder = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        Toast toast = new Toast(getApplicationContext());
        /*String fileType = ".txt";
        String concatFileName = dataDate+fileType;*/
        File file = new File(folder, "test.txt");
        String data = getdata(file);
        if (data != null) {
            TextView textView = (TextView) findViewById(R.id.displayData);
            textView.setText(data);
        } else {
            toast.setText("No Data Found");
            toast.show();
        }

    }
    private String getdata(File myfile) {
        FileInputStream fileInputStream = null;
        try {
            fileInputStream = new FileInputStream(myfile);
            int i = -1;
            StringBuffer buffer = new StringBuffer();
            while ((i = fileInputStream.read()) != -1) {
                buffer.append((char) i);
            }
            return buffer.toString();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (fileInputStream != null) {
                try {
                    fileInputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return null;
    }
}




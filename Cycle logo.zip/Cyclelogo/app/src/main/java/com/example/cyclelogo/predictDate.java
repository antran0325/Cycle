package com.example.cyclelogo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.*;

public class predictDate {
    SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy");
    Calendar c = Calendar.getInstance();
    public String getMenstruationEnd(String periodStart){
        try {
            c.setTime(sdf.parse(periodStart));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        c.add(Calendar.DATE, 5);  // number of days to add, can also use Calendar.DAY_OF_MONTH in place of Calendar.DATE
        SimpleDateFormat sdf1 = new SimpleDateFormat("MMM dd, yyyy");
        String periodEnd = sdf1.format(c.getTime());
        return periodEnd;
    }
    public String getFollicularPhaseStart(String periodEnd){
        try {
            c.setTime(sdf.parse(periodEnd));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        c.add(Calendar.DATE, 1);  // number of days to add, can also use Calendar.DAY_OF_MONTH in place of Calendar.DATE
        SimpleDateFormat sdf1 = new SimpleDateFormat("MMM dd, yyyy");
        String follicularPhaseStart = sdf1.format(c.getTime());
        return follicularPhaseStart;
    }
    public String getFollicularPhaseEnd(String follicularPhaseStart){
        try {
            c.setTime(sdf.parse(follicularPhaseStart));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        c.add(Calendar.DATE, 5);  // number of days to add, can also use Calendar.DAY_OF_MONTH in place of Calendar.DATE
        SimpleDateFormat sdf1 = new SimpleDateFormat("MMM dd, yyyy");
        String follicularPhaseEnd = sdf1.format(c.getTime());
        return follicularPhaseEnd;
    }

    public String getOvulationStart(String follicularPhaseEnd){
        try {
            c.setTime(sdf.parse(follicularPhaseEnd));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        c.add(Calendar.DATE, 1);  // number of days to add, can also use Calendar.DAY_OF_MONTH in place of Calendar.DATE
        SimpleDateFormat sdf1 = new SimpleDateFormat("MMM dd, yyyy");
        String ovulationStart = sdf1.format(c.getTime());
        return ovulationStart;
    }
    public String getOvulationEnd(String ovulationStart){
        try {
            c.setTime(sdf.parse(ovulationStart));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        c.add(Calendar.DATE, 5);  // number of days to add, can also use Calendar.DAY_OF_MONTH in place of Calendar.DATE
        SimpleDateFormat sdf1 = new SimpleDateFormat("MMM dd, yyyy");
        String ovulationEnd = sdf1.format(c.getTime());
        return ovulationEnd;
    }
    public String getLutealPhaseStart(String ovulationEnd){
        try {
            c.setTime(sdf.parse(ovulationEnd));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        c.add(Calendar.DATE, 1);  // number of days to add, can also use Calendar.DAY_OF_MONTH in place of Calendar.DATE
        SimpleDateFormat sdf1 = new SimpleDateFormat("MMM dd, yyyy");
        String lutealPhaseStart = sdf1.format(c.getTime());
        return lutealPhaseStart;
    }

    public String getLutealPhaseEnd(String lutealPhaseStart){
        try {
            c.setTime(sdf.parse(lutealPhaseStart));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        c.add(Calendar.DATE, 5);  // number of days to add, can also use Calendar.DAY_OF_MONTH in place of Calendar.DATE
        SimpleDateFormat sdf1 = new SimpleDateFormat("MMM dd, yyyy");
        String lutealPhaseEnd = sdf1.format(c.getTime());
        return lutealPhaseEnd;
    }
    public String getNextMenstruation(String lutealEnd){
        try {
            c.setTime(sdf.parse(lutealEnd));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        c.add(Calendar.DATE, 1);  // number of days to add, can also use Calendar.DAY_OF_MONTH in place of Calendar.DATE
        SimpleDateFormat sdf1 = new SimpleDateFormat("MMM dd, yyyy");
        String periodStart = sdf1.format(c.getTime());
        return periodStart;
    }
}

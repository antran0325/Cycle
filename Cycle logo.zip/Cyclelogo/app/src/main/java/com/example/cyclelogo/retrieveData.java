package com.example.cyclelogo;

import java.text.SimpleDateFormat;
import java.io.File;  // Import the File class
import java.io.IOException;  // Import the IOException class to handle errors

public class retrieveData  {
    private String bleeding;
    private String feeling;
    private String skinChoice;
    private String hairChoice;
    private String symptomChoice;
    public String getDate() {
        //TextView dateText  = (TextView) findViewById(R.id.textView2);
        long date = System.currentTimeMillis();
        SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy");
        String dateString = sdf.format(date);
        //dateText.setText(dateString);
        return dateString;
    }
    public void setBleeding(String bleed) {
        bleeding = bleed;
    }
    public String getBleeding(){
        return bleeding;
    }
    public void setFeeling (String feel){ feeling = feel;}
    public String getFeeling() {return feeling; }
    public void setSkinChoice(String skin) {skinChoice = skin;}
    public String getSkinChoice() {return skinChoice;}
    public void setHairChoice(String hair) {hairChoice = hair;}
    public String getHairChoice(){return hairChoice;}
    public void setSymptomChoice(String symptoms) {symptomChoice = symptoms; }
    public  String getSymptomChoice(){return symptomChoice;}
}
